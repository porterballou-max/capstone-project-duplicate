﻿

// Write JavaScript code.
